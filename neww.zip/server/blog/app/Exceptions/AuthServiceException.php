<?php
namespace App\Exceptions;

use Exception;

class AuthServiceException extends Exception
{
    //
}
