<?php
namespace App\Exceptions;

use Exception;

class ValidationFailedException extends Exception
{
    //
}
