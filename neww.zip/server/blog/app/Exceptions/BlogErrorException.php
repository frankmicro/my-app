<?php
namespace App\Exceptions;

use Exception;


class BlogErrorException extends Exception
{
    //
}
