<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\TransactionModel;
use App\Services\CustomValidationService;
use App\Services\Traits\ResponseCodeTrait;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    protected $request;

    protected $model;

    protected $custom_validation;

    use ResponseCodeTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request, TransactionModel $model, CustomValidationService $custom_validation)
    {
        $this->request           = $request;
        $this->custom_validation = $custom_validation;
        $this->model             = $model;
    }

    public function lists()
    {

    }

    public function store()
    {
        $data = $this->request->all();
        $data['status'] = $data['isImportant'];
        $data['description'] = $data['myckeditor'];

        $required_fields = ['name', 'amount', 'isImportant'];

        $rules = $this->custom_validation->getRules($required_fields);
        
        $this->validateApi($data, $rules);

        $response = self::getResponseCode(1);

        $this->model->create($data);

        $response['message'] = "Transaction created successfully!";

        return $this->response($response);
    }

    public function update($id)
    {

    }
}
